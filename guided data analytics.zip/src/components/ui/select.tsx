import React, { useState, useRef, useEffect } from 'react';

interface SelectProps {
  value?: string;
  onValueChange?: (value: string) => void;
  children: React.ReactNode;
  placeholder?: string;
}

interface SelectItemProps {
  value: string;
  children: React.ReactNode;
  onClick?: (value: string) => void;
}

export const SelectItem: React.FC<SelectItemProps> = ({ value, children, onClick }) => {
  return (
    <div 
      className="relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none hover:bg-gray-100 focus:bg-gray-100"
      onClick={() => onClick?.(value)}
    >
      {children}
    </div>
  );
};

export const Select: React.FC<SelectProps> = ({ value, onValueChange, children, placeholder }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedValue, setSelectedValue] = useState(value || '');
  const selectRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setSelectedValue(value || '');
  }, [value]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (selectRef.current && !selectRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleItemClick = (itemValue: string) => {
    setSelectedValue(itemValue);
    onValueChange?.(itemValue);
    setIsOpen(false);
  };

  // Extract children and find the selected one
  const items = React.Children.toArray(children).filter(
    (child): child is React.ReactElement<SelectItemProps> => 
      React.isValidElement(child) && child.type === SelectItem
  );

  const selectedItem = items.find(item => item.props.value === selectedValue);

  return (
    <div ref={selectRef} className="relative">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex h-10 w-full items-center justify-between rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
      >
        <span className="block truncate">
          {selectedItem ? selectedItem.props.children : placeholder}
        </span>
        <svg className="h-4 w-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      
      {isOpen && (
        <div className="absolute top-full left-0 right-0 z-50 mt-1 min-w-[8rem] overflow-hidden rounded-md border border-gray-200 bg-white text-gray-950 shadow-md">
          <div className="p-1">
            {React.Children.map(children, child => 
              React.isValidElement(child) && child.type === SelectItem
                ? React.cloneElement(child as React.ReactElement<SelectItemProps>, {
                    onClick: handleItemClick
                  })
                : child
            )}
          </div>
        </div>
      )}
    </div>
  );
};

// Export a compound component interface for backward compatibility
export const SelectTrigger: React.FC<{ children: React.ReactNode; className?: string }> = ({ children }) => <>{children}</>;
export const SelectValue: React.FC<{ placeholder?: string }> = ({ placeholder }) => <span>{placeholder}</span>;
export const SelectContent: React.FC<{ children: React.ReactNode }> = ({ children }) => <>{children}</>;