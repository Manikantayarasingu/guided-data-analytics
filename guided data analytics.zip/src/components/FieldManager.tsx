import React from 'react';
import { useDataStore } from '../hooks/useDataStore';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Eye, EyeOff, Edit2 } from 'lucide-react';

export const FieldManager: React.FC = () => {
  const { fields, updateField } = useDataStore();

  const handleNameChange = (id: string, newName: string) => {
    updateField(id, { name: newName });
  };

  const handleTypeChange = (id: string, newType: 'text' | 'numeric' | 'date') => {
    updateField(id, { type: newType });
  };

  const toggleVisibility = (id: string) => {
    const field = fields.find(f => f.id === id);
    if (field) {
      updateField(id, { visible: !field.visible });
    }
  };

  return (
    <div className="space-y-4">
      {fields.map((field) => (
        <div key={field.id} className="flex items-center gap-4 p-4 border rounded-lg bg-white">
          <div className="flex-1">
            <Input
              value={field.name}
              onChange={(e) => handleNameChange(field.id, e.target.value)}
              className="font-medium"
            />
          </div>
          
          <div className="w-32">
            <Select
              value={field.type}
              onValueChange={(value: 'text' | 'numeric' | 'date') => handleTypeChange(field.id, value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="text">Text</SelectItem>
                <SelectItem value="numeric">Number</SelectItem>
                <SelectItem value="date">Date</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={() => toggleVisibility(field.id)}
            className={field.visible ? 'text-green-600' : 'text-gray-400'}
          >
            {field.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
          </Button>
        </div>
      ))}
      
      {fields.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No fields available. Please upload data first.
        </div>
      )}
    </div>
  );
};