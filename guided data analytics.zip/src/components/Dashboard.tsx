import { useDataStore } from '../hooks/useDataStore';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';

// Recharts components - import them individually to avoid issues
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell
} from 'recharts';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export function Dashboard() {
  const { currentStep, xAxis, yAxis, chartType, data, fields, aggregation } = useDataStore();
  
  if (currentStep !== 'dashboard') return null;
  
  // Get field configurations
  const xField = fields.find(f => f.name === xAxis);
  const yFields = fields.filter(f => yAxis.includes(f.name));
  
  // Process data for chart
  const processChartData = () => {
    if (!xAxis || yAxis.length === 0) return [];
    
    // Group data by x-axis value
    const grouped = data.reduce((acc, row) => {
      const key = row[xAxis];
      if (!acc[key]) {
        acc[key] = { [xAxis]: key };
      }
      
      // Add y-axis values
      yAxis.forEach(y => {
        const value = parseFloat(row[y]) || 0;
        if (!acc[key][y]) {
          acc[key][y] = 0;
        }
        acc[key][y] += value;
      });
      
      return acc;
    }, {} as Record<string, any>);
    
    return Object.values(grouped);
  };
  
  const chartData = processChartData();
  
  // Render chart based on type
  const renderChart = () => {
    switch (chartType) {
      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey={xAxis || ''} />
              <YAxis />
              <Tooltip />
              <Legend />
              {yFields.map((field, idx) => (
                <Bar key={field.name} dataKey={field.name} fill={COLORS[idx % COLORS.length]} name={field.displayName} />
              ))}
            </BarChart>
          </ResponsiveContainer>
        );
      
      case 'line':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey={xAxis || ''} />
              <YAxis />
              <Tooltip />
              <Legend />
              {yFields.map((field, idx) => (
                <Line key={field.name} type="monotone" dataKey={field.name} stroke={COLORS[idx % COLORS.length]} name={field.displayName} />
              ))}
            </LineChart>
          </ResponsiveContainer>
        );
      
      case 'pie':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <PieChart>
              <Pie
                data={chartData}
                dataKey={yAxis[0] || ''}
                nameKey={xAxis || ''}
                cx="50%"
                cy="50%"
                outerRadius={120}
                label
              >
                {chartData.map((entry, idx) => (
                  <Cell key={`cell-${idx}`} fill={COLORS[idx % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        );
      
      case 'scatter':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <ScatterChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey={xAxis || ''} type="number" />
              <YAxis dataKey={yAxis[0] || ''} type="number" />
              <Tooltip />
              <Scatter fill="#3b82f6" />
            </ScatterChart>
          </ResponsiveContainer>
        );
      
      case 'table':
        return (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-50">
                  <th className="border border-gray-300 px-4 py-2 text-left">{xField?.displayName}</th>
                  {yFields.map(field => (
                    <th key={field.name} className="border border-gray-300 px-4 py-2 text-left">
                      {field.displayName} ({aggregation})
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {chartData.map((row, idx) => (
                  <tr key={idx} className="hover:bg-gray-50">
                    <td className="border border-gray-300 px-4 py-2">{row[xAxis || '']}</td>
                    {yFields.map(field => (
                      <td key={field.name} className="border border-gray-300 px-4 py-2">
                        {row[field.name]?.toFixed(2)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      
      default:
        return <div>Chart type not supported</div>;
    }
  };
  
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Your Chart
            <Badge variant="secondary">Step 4</Badge>
          </CardTitle>
          <CardDescription>
            Here's your generated chart based on the selected configuration.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Chart Configuration Summary */}
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline">X: {xField?.displayName}</Badge>
              {yFields.map(field => (
                <Badge key={field.name} variant="outline">
                  Y: {field.displayName}
                </Badge>
              ))}
              <Badge variant="outline">Type: {chartType}</Badge>
              <Badge variant="outline">Aggregation: {aggregation}</Badge>
            </div>
            
            {/* Chart */}
            <div className="bg-white p-4 rounded-lg border">
              {renderChart()}
            </div>
            
            {/* Actions */}
            <div className="flex gap-2">
              <Button onClick={() => window.print()}>
                Export as PNG
              </Button>
              <Button variant="outline" onClick={() => window.location.reload()}>
                Start Over
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}