import { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { useDataStore, FieldConfig } from '../hooks/useDataStore';
import { inferFieldTypes } from '../utils/typeInference';
import { Search, Eye, EyeOff, Edit2, Check, X } from 'lucide-react';

export function DataPreview() {
  const { data, setCurrentStep, fields, setFields } = useDataStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [editingField, setEditingField] = useState<string | null>(null);
  const [tempName, setTempName] = useState('');
  const rowsPerPage = 10;
  
  // Infer field types when data changes
  useEffect(() => {
    if (data.length > 0 && fields.length === 0) {
      const fieldTypes = inferFieldTypes(data);
      const initialFields: FieldConfig[] = Object.keys(fieldTypes).map(name => ({
        name,
        displayName: name,
        type: fieldTypes[name],
        visible: true
      }));
      setFields(initialFields);
    }
  }, [data, fields.length, setFields]);
  
  const filteredData = data.filter(row =>
    Object.values(row).some(value =>
      value.toLowerCase().includes(searchTerm.toLowerCase())
    )
  );
  
  const totalPages = Math.ceil(filteredData.length / rowsPerPage);
  const startIndex = (currentPage - 1) * rowsPerPage;
  const paginatedData = filteredData.slice(startIndex, startIndex + rowsPerPage);
  
  const visibleFields = fields.filter(f => f.visible);
  
  function handleExportCSV() {
    if (data.length === 0) return;
    
    const headers = visibleFields.map(f => f.displayName).join(',');
    const rows = data.map(row => 
      visibleFields.map(f => `"${row[f.name] || ''}"`).join(',')
    );
    
    const csv = [headers, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'data-export.csv';
    a.click();
    URL.revokeObjectURL(url);
  }
  
  function toggleFieldVisibility(fieldName: string) {
    setFields(fields.map(f => 
      f.name === fieldName ? { ...f, visible: !f.visible } : f
    ));
  }
  
  function startEditing(fieldName: string, currentName: string) {
    setEditingField(fieldName);
    setTempName(currentName);
  }
  
  function saveFieldEdit(fieldName: string) {
    setFields(fields.map(f => 
      f.name === fieldName ? { ...f, displayName: tempName } : f
    ));
    setEditingField(null);
    setTempName('');
  }
  
  function cancelEdit() {
    setEditingField(null);
    setTempName('');
  }
  
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Data Preview
            <Badge variant="secondary">Step 2</Badge>
          </CardTitle>
          <CardDescription>
            Review your data, rename columns, and select which fields to include in your chart.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search and Export */}
          <div className="flex gap-4 items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search data..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                className="pl-10"
              />
            </div>
            <Button onClick={handleExportCSV} variant="outline">
              Export CSV
            </Button>
          </div>
          
          {/* Field Configuration */}
          <div className="space-y-2">
            <h3 className="text-sm font-medium">Field Configuration</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
              {fields.map(field => (
                <div key={field.name} className="flex items-center gap-2 p-2 border rounded">
                  <button
                    onClick={() => toggleFieldVisibility(field.name)}
                    className="p-1 hover:bg-gray-100 rounded"
                  >
                    {field.visible ? (
                      <Eye className="w-4 h-4 text-green-600" />
                    ) : (
                      <EyeOff className="w-4 h-4 text-gray-400" />
                    )}
                  </button>
                  
                  {editingField === field.name ? (
                    <div className="flex items-center gap-1 flex-1">
                      <Input
                        value={tempName}
                        onChange={(e) => setTempName(e.target.value)}
                        className="h-8 text-sm"
                      />
                      <button
                        onClick={() => saveFieldEdit(field.name)}
                        className="p-1 hover:bg-green-100 rounded"
                      >
                        <Check className="w-4 h-4 text-green-600" />
                      </button>
                      <button
                        onClick={cancelEdit}
                        className="p-1 hover:bg-red-100 rounded"
                      >
                        <X className="w-4 h-4 text-red-600" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 flex-1">
                      <span className="text-sm flex-1">{field.displayName}</span>
                      <Badge variant="outline" className="text-xs">
                        {field.type}
                      </Badge>
                      <button
                        onClick={() => startEditing(field.name, field.displayName)}
                        className="p-1 hover:bg-gray-100 rounded"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          {/* Data Table */}
          <div className="border rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    {visibleFields.map(field => (
                      <th key={field.name} className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {field.displayName}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {paginatedData.map((row, idx) => (
                    <tr key={idx} className="hover:bg-gray-50">
                      {visibleFields.map(field => (
                        <td key={field.name} className="px-4 py-2 text-sm text-gray-900">
                          {row[field.name] || ''}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          
          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-700">
                Showing {startIndex + 1} to {Math.min(startIndex + rowsPerPage, filteredData.length)} of {filteredData.length} results
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                >
                  Previous
                </Button>
                <span className="px-3 py-1 text-sm">
                  Page {currentPage} of {totalPages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
          
          {/* Navigation */}
          <div className="flex justify-between pt-4">
            <Button variant="outline" onClick={() => setCurrentStep('upload')}>
              Back
            </Button>
            <Button onClick={() => setCurrentStep('configure')}>
              Configure Chart
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}