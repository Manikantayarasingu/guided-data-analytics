import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { useDataStore } from '../hooks/useDataStore';
import { Upload, FileText, Database } from 'lucide-react';

export default function DataUpload() {
  const { data, setData, setCurrentStep } = useDataStore();
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState('');
  
  function handleDragOver(e: React.DragEvent) {
    e.preventDefault();
    setIsDragging(true);
  }
  
  function handleDragLeave(e: React.DragEvent) {
    e.preventDefault();
    setIsDragging(false);
  }
  
  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      processFile(files[0]);
    }
  }
  
  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files;
    if (files && files.length > 0) {
      processFile(files[0]);
    }
  }
  
  function processFile(file: File) {
    setError('');
    
    if (file.type === 'text/csv' || file.name.endsWith('.csv')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const text = e.target?.result as string;
          const lines = text.split('\n').filter(line => line.trim());
          
          if (lines.length < 2) {
            setError('File must contain at least a header row and one data row');
            return;
          }
          
          const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
          const data = lines.slice(1).map(line => {
            const values = line.split(',').map(v => v.trim().replace(/"/g, ''));
            const row: Record<string, string> = {};
            headers.forEach((header, index) => {
              row[header] = values[index] || '';
            });
            return row;
          });
          
          setData(data);
          setCurrentStep('preview');
        } catch (err) {
          setError('Failed to parse CSV file');
        }
      };
      reader.readAsText(file);
    } else if (file.type === 'application/json' || file.name.endsWith('.json')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const json = JSON.parse(e.target?.result as string);
          if (Array.isArray(json) && json.length > 0) {
            setData(json);
            setCurrentStep('preview');
          } else {
            setError('JSON must be an array of objects');
          }
        } catch (err) {
          setError('Failed to parse JSON file');
        }
      };
      reader.readAsText(file);
    } else {
      setError('Please upload a CSV or JSON file');
    }
  }
  
  if (data.length > 0) return null;
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          Upload Data
          <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">Step 1</span>
        </CardTitle>
        <CardDescription>
          Upload your CSV or JSON file to get started. The system will automatically detect and parse your data.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
          <p className="text-lg font-medium mb-2">Drop your file here</p>
          <p className="text-sm text-gray-500 mb-4">or click to browse</p>
          <input
            type="file"
            accept=".csv,.json"
            onChange={handleFileSelect}
            className="hidden"
            id="file-upload"
          />
          <Button asChild>
            <label htmlFor="file-upload" className="cursor-pointer">
              Choose File
            </label>
          </Button>
        </div>
        
        {error && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
            {error}
          </div>
        )}
        
        <div className="mt-6 grid grid-cols-2 gap-4">
          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
            <FileText className="w-8 h-8 text-blue-500" />
            <div>
              <p className="font-medium text-sm">CSV Files</p>
              <p className="text-xs text-gray-500">Comma-separated values</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
            <Database className="w-8 h-8 text-green-500" />
            <div>
              <p className="font-medium text-sm">JSON Files</p>
              <p className="text-xs text-gray-500">Array of objects</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}