import React from 'react';
import { useDataStore } from '../hooks/useDataStore';
import { Button } from './ui/button';
import { Download, FileText, Image } from 'lucide-react';

export const ExportControls: React.FC = () => {
  const { exportCSV, charts, exportChartAsPNG } = useDataStore();

  return (
    <div className="flex gap-2">
      <Button variant="outline" onClick={exportCSV}>
        <FileText className="w-4 h-4 mr-2" />
        Export CSV
      </Button>
      {charts.length > 0 && (
        <Button variant="outline" onClick={() => charts.forEach(c => exportChartAsPNG(c.id))}>
          <Image className="w-4 h-4 mr-2" />
          Export All Charts
        </Button>
      )}
    </div>
  );
};