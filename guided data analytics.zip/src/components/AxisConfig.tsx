import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Input } from '../components/ui/input';
import { useDataStore } from '../hooks/useDataStore';
import { ChartType, AggregationType, FieldType, DataField } from '../hooks/useDataStore';
import { 
  BarChart3, LineChart, PieChart, ScatterChart, Table, 
  X, Plus, ArrowRight, Search, Eye, TrendingUp, Calendar, Hash, Type,
  ChevronDown, ChevronUp, Zap, Lightbulb, Calculator, Info
} from 'lucide-react';

const chartOptions = [
  { 
    value: 'bar', 
    label: 'Bar Chart', 
    icon: BarChart3,
    description: 'Compare values across categories',
    bestFor: 'Categorical data with numeric values',
    example: 'Sales by product, population by country'
  },
  { 
    value: 'line', 
    label: 'Line Chart', 
    icon: LineChart,
    description: 'Show trends over time',
    bestFor: 'Date/time or sequential data',
    example: 'Revenue over months, temperature over days'
  },
  { 
    value: 'pie', 
    label: 'Pie Chart', 
    icon: PieChart,
    description: 'Show proportions of a whole',
    bestFor: 'Single categorical field with percentages',
    example: 'Market share, budget allocation'
  },
  { 
    value: 'scatter', 
    label: 'Scatter Plot', 
    icon: ScatterChart,
    description: 'Show relationship between two numeric values',
    bestFor: 'Two numeric fields',
    example: 'Height vs weight, price vs demand'
  },
  { 
    value: 'table', 
    label: 'Data Table', 
    icon: Table,
    description: 'Display raw data with aggregations',
    bestFor: 'Detailed data review',
    example: 'Summary statistics, grouped data'
  },
] as const;

const aggregationOptions = [
  { 
    value: 'sum', 
    label: 'Sum', 
    icon: <Calculator className="h-4 w-4" />,
    description: 'Add all values together',
    formula: 'Σ(x₁ + x₂ + ... + xₙ)',
    example: 'Total sales, total revenue',
    useCase: 'When you want the grand total'
  },
  { 
    value: 'mean', 
    label: 'Average', 
    icon: <TrendingUp className="h-4 w-4" />,
    description: 'Calculate the arithmetic mean',
    formula: '(x₁ + x₂ + ... + xₙ) / n',
    example: 'Average order value, average temperature',
    useCase: 'When you want the typical value'
  },
  { 
    value: 'count', 
    label: 'Count', 
    icon: <Hash className="h-4 w-4" />,
    description: 'Count the number of records',
    formula: 'Number of items in group',
    example: 'Number of orders, number of customers',
    useCase: 'When you want frequency or volume'
  },
  { 
    value: 'min', 
    label: 'Minimum', 
    icon: <ArrowRight className="h-4 w-4 rotate-270" />,
    description: 'Find the smallest value',
    formula: 'min(x₁, x₂, ..., xₙ)',
    example: 'Lowest price, minimum temperature',
    useCase: 'When you need the lower bound'
  },
  { 
    value: 'max', 
    label: 'Maximum', 
    icon: <ArrowRight className="h-4 w-4 rotate-90" />,
    description: 'Find the largest value',
    formula: 'max(x₁, x₂, ..., xₙ)',
    example: 'Highest score, maximum temperature',
    useCase: 'When you need the upper bound'
  },
] as const;

interface FieldStats {
  unique: number;
  nulls: number;
  sample: string[];
  isNumeric: boolean;
  isDate: boolean;
  isCategorical: boolean;
}

export function AxisConfig() {
  const {
    fields,
    data,
    xAxis,
    yAxis,
    chartType,
    aggregation,
    setXAxis,
    setYAxis,
    setChartType,
    setAggregation,
    setCurrentStep,
  } = useDataStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [expandedField, setExpandedField] = useState<string | null>(null);
  const [showRecommendations, setShowRecommendations] = useState(false);
  const [selectedAggregation, setSelectedAggregation] = useState<AggregationType>(aggregation);
  const [selectedChartType, setSelectedChartType] = useState<ChartType>(chartType);

  // Calculate field statistics
  const fieldStats = useMemo(() => {
    const stats: Record<string, FieldStats> = {};
    
    fields.forEach(field => {
      const values = data.map(row => row[field.name]).filter(v => v !== null && v !== undefined && v !== '');
      const unique = new Set(values).size;
      const nulls = data.length - values.length;
      const sample = values.slice(0, 3);
      
      stats[field.name] = {
        unique,
        nulls,
        sample,
        isNumeric: field.type === 'numeric',
        isDate: field.type === 'date',
        isCategorical: field.type === 'text'
      };
    });
    
    return stats;
  }, [fields, data]);

  // Filter fields based on search
  const filteredFields = useMemo(() => {
    return fields.filter(field => 
      field.visible && (
        field.displayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        field.name.toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  }, [fields, searchTerm]);

  const categoricalFields = filteredFields.filter(f => f.type !== 'numeric');
  const numericFields = filteredFields.filter(f => f.type === 'numeric');
  const selectedXField = fields.find(f => f.name === xAxis);
  const selectedYFields = fields.filter(f => yAxis.includes(f.name));

  // Smart recommendations
  const recommendations = useMemo(() => {
    const recs = {
      xAxis: [] as DataField[],
      yAxis: [] as DataField[],
      chartType: 'bar' as ChartType,
      aggregation: 'mean' as AggregationType
    };

    // Recommend X axis
    const goodCategorical = categoricalFields.filter(f => {
      const stats = fieldStats[f.name];
      return stats.unique > 1 && stats.unique < 50;
    });

    if (goodCategorical.length > 0) {
      recs.xAxis = goodCategorical.slice(0, 2);
    } else {
      const dateFields = categoricalFields.filter(f => f.type === 'date');
      if (dateFields.length > 0) {
        recs.xAxis = dateFields.slice(0, 2);
      } else {
        recs.xAxis = categoricalFields.slice(0, 2);
      }
    }

    // Recommend Y axis
    const goodNumeric = numericFields.filter(f => {
      const stats = fieldStats[f.name];
      return stats.nulls < data.length * 0.5;
    });

    recs.yAxis = goodNumeric.slice(0, 3);

    // Recommend chart type and aggregation
    if (recs.xAxis.some(f => f.type === 'date')) {
      recs.chartType = 'line';
      recs.aggregation = 'sum';
    } else if (recs.xAxis.length === 1 && recs.yAxis.length === 1) {
      recs.chartType = 'bar';
      recs.aggregation = 'mean';
    }

    return recs;
  }, [categoricalFields, numericFields, fieldStats, data.length]);

  const handleAutoGenerate = () => {
    if (recommendations.xAxis.length > 0 && !xAxis) {
      setXAxis(recommendations.xAxis[0].name);
    }
    
    if (recommendations.yAxis.length > 0 && yAxis.length === 0) {
      setYAxis([recommendations.yAxis[0].name]);
    }
    
    setSelectedChartType(recommendations.chartType);
    setChartType(recommendations.chartType);
    setSelectedAggregation(recommendations.aggregation);
    setAggregation(recommendations.aggregation);
    setShowRecommendations(false);
  };

  const handleAddToXAxis = (fieldName: string) => {
    setXAxis(fieldName);
  };

  const handleAddToYAxis = (fieldName: string) => {
    if (!yAxis.includes(fieldName)) {
      setYAxis([...yAxis, fieldName]);
    }
  };

  const handleRemoveFromYAxis = (fieldName: string) => {
    setYAxis(yAxis.filter(f => f !== fieldName));
  };

  const handleContinue = () => {
    // Apply selected values
    setChartType(selectedChartType);
    setAggregation(selectedAggregation);
    setCurrentStep('dashboard');
  };

  const getFieldIcon = (type: FieldType) => {
    switch (type) {
      case 'numeric':
        return <Hash className="h-4 w-4 text-blue-500" />;
      case 'date':
        return <Calendar className="h-4 w-4 text-green-500" />;
      default:
        return <Type className="h-4 w-4 text-purple-500" />;
    }
  };

  const getTypeColor = (type: FieldType) => {
    switch (type) {
      case 'numeric':
        return 'bg-blue-50 border-blue-200 text-blue-700';
      case 'date':
        return 'bg-green-50 border-green-200 text-green-700';
      default:
        return 'bg-purple-50 border-purple-200 text-purple-700';
    }
  };

  // Validation
  const isValidSelection = xAxis && yAxis.length > 0 && selectedChartType && selectedAggregation;

  return (
    <div className="space-y-6">
      {/* Smart Recommendations Card */}
      <Card className="border-2 border-dashed border-blue-200 bg-blue-50/50">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-blue-700">
            <Lightbulb className="h-5 w-5" />
            Smart Recommendations
          </CardTitle>
          <CardDescription>
            AI-powered suggestions for optimal chart configuration
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {showRecommendations ? (
            <div className="space-y-3">
              <div>
                <h4 className="text-sm font-medium mb-2">Recommended X-Axis:</h4>
                <div className="flex flex-wrap gap-2">
                  {recommendations.xAxis.map(field => (
                    <Button
                      key={field.name}
                      size="sm"
                      variant="outline"
                      onClick={() => handleAddToXAxis(field.name)}
                      className="bg-white"
                    >
                      {getFieldIcon(field.type)}
                      {field.displayName}
                    </Button>
                  ))}
                </div>
              </div>
              
              <div>
                <h4 className="text-sm font-medium mb-2">Recommended Y-Axis:</h4>
                <div className="flex flex-wrap gap-2">
                  {recommendations.yAxis.map(field => (
                    <Button
                      key={field.name}
                      size="sm"
                      variant="outline"
                      onClick={() => handleAddToYAxis(field.name)}
                      className="bg-white"
                    >
                      {getFieldIcon(field.type)}
                      {field.displayName}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <Button onClick={handleAutoGenerate} className="flex-1">
                  <Zap className="h-4 w-4 mr-2" />
                  Apply All Recommendations
                </Button>
                <Button variant="outline" onClick={() => setShowRecommendations(false)}>
                  Dismiss
                </Button>
              </div>
            </div>
          ) : (
            <Button onClick={() => setShowRecommendations(true)} variant="outline" className="w-full">
              <Lightbulb className="h-4 w-4 mr-2" />
              Show Smart Recommendations
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Current Selection Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Current Selection
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* X Axis Display */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-600">X-Axis Field</label>
              {selectedXField ? (
                <div className={`p-3 rounded-lg border ${getTypeColor(selectedXField.type)}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getFieldIcon(selectedXField.type)}
                      <span className="font-medium">{selectedXField.displayName}</span>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setXAxis(null)}
                      className="h-6 w-6 p-0 hover:bg-red-100"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                  <div className="text-xs mt-1 opacity-75">
                    {fieldStats[selectedXField.name]?.unique} unique values
                  </div>
                </div>
              ) : (
                <div className="p-3 rounded-lg border-2 border-dashed border-slate-300 text-center text-slate-400">
                  No field selected
                </div>
              )}
            </div>

            {/* Y Axis Display */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-600">Y-Axis Fields</label>
              <div className="space-y-2">
                {selectedYFields.length > 0 ? (
                  selectedYFields.map(field => (
                    <div key={field.name} className={`p-3 rounded-lg border ${getTypeColor(field.type)}`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {getFieldIcon(field.type)}
                          <span className="font-medium">{field.displayName}</span>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleRemoveFromYAxis(field.name)}
                          className="h-6 w-6 p-0 hover:bg-red-100"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="text-xs mt-1 opacity-75">
                        {fieldStats[field.name]?.unique} unique values
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-3 rounded-lg border-2 border-dashed border-slate-300 text-center text-slate-400">
                    No fields selected
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Field Explorer */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Field Explorer
          </CardTitle>
          <CardDescription>
            Browse and select fields for visualization
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Search fields..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Field List */}
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {filteredFields.map(field => {
              const stats = fieldStats[field.name];
              const isExpanded = expandedField === field.name;
              const isXSelected = xAxis === field.name;
              const isYSelected = yAxis.includes(field.name);

              return (
                <div key={field.name} className="border rounded-lg">
                  <div className={`p-3 ${getTypeColor(field.type)}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {getFieldIcon(field.type)}
                        <div>
                          <div className="font-medium">{field.displayName}</div>
                          <div className="text-xs opacity-75">
                            {stats.unique} unique • {stats.nulls} empty
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {/* Action buttons */}
                        {!isXSelected && field.type !== 'numeric' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleAddToXAxis(field.name)}
                            className="h-7 text-xs"
                          >
                            X-Axis
                          </Button>
                        )}
                        
                        {!isYSelected && field.type === 'numeric' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleAddToYAxis(field.name)}
                            className="h-7 text-xs"
                          >
                            Y-Axis
                          </Button>
                        )}

                        {/* Expand/Collapse */}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setExpandedField(isExpanded ? null : field.name)}
                          className="h-7 w-7 p-0"
                        >
                          {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>

                    {/* Expanded view with sample data */}
                    {isExpanded && (
                      <div className="mt-3 pt-3 border-t border-current/20">
                        <div className="text-xs space-y-1">
                          <div><strong>Sample values:</strong></div>
                          <div className="flex flex-wrap gap-1">
                            {stats.sample.map((value, idx) => (
                              <span key={idx} className="bg-white/50 px-2 py-1 rounded text-xs">
                                {String(value)}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* MANDATORY: Aggregate Function Selection */}
      <Card className="border-2 border-orange-200 bg-orange-50/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-orange-700">
            <Calculator className="h-5 w-5" />
            Select Aggregate Function
            <span className="text-red-500 text-sm">*</span>
          </CardTitle>
          <CardDescription>
            Choose how to aggregate your numeric data
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {aggregationOptions.map((option) => (
              <div
                key={option.value}
                className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  selectedAggregation === option.value
                    ? 'border-orange-400 bg-orange-100 shadow-sm'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
                onClick={() => setSelectedAggregation(option.value as AggregationType)}
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className={`p-1 rounded ${selectedAggregation === option.value ? 'bg-orange-200' : 'bg-slate-100'}`}>
                    {option.icon}
                  </div>
                  <h3 className="font-semibold">{option.label}</h3>
                </div>
                <p className="text-sm text-slate-600 mb-2">{option.description}</p>
                <div className="text-xs space-y-1">
                  <div className="font-mono bg-slate-100 p-1 rounded">{option.formula}</div>
                  <div className="text-slate-500">
                    <strong>Example:</strong> {option.example}
                  </div>
                  <div className="text-slate-500">
                    <strong>Use when:</strong> {option.useCase}
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {!selectedAggregation && (
            <div className="text-sm text-red-600 flex items-center gap-2">
              <Info className="h-4 w-4" />
              Please select an aggregate function to continue
            </div>
          )}
        </CardContent>
      </Card>

      {/* MANDATORY: Chart Type Selection */}
      <Card className="border-2 border-blue-200 bg-blue-50/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-700">
            <TrendingUp className="h-5 w-5" />
            Select Chart Type
            <span className="text-red-500 text-sm">*</span>
          </CardTitle>
          <CardDescription>
            Choose the best visualization for your data
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {chartOptions.map((option) => {
              const Icon = option.icon;
              const isRecommended = recommendations.chartType === option.value;
              
              return (
                <div
                  key={option.value}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all relative ${
                    selectedChartType === option.value
                      ? 'border-blue-400 bg-blue-100 shadow-sm'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                  onClick={() => setSelectedChartType(option.value as ChartType)}
                >
                  {isRecommended && (
                    <div className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full">
                      Recommended
                    </div>
                  )}
                  
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`p-1 rounded ${selectedChartType === option.value ? 'bg-blue-200' : 'bg-slate-100'}`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <h3 className="font-semibold">{option.label}</h3>
                  </div>
                  <p className="text-sm text-slate-600 mb-2">{option.description}</p>
                  <div className="text-xs space-y-1">
                    <div className="text-slate-500">
                      <strong>Best for:</strong> {option.bestFor}
                    </div>
                    <div className="text-slate-500">
                      <strong>Example:</strong> {option.example}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          
          {!selectedChartType && (
            <div className="text-sm text-red-600 flex items-center gap-2">
              <Info className="h-4 w-4" />
              Please select a chart type to continue
            </div>
          )}
        </CardContent>
      </Card>

      {/* Continue Button */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col items-center space-y-4">
            <div className="text-center">
              <h3 className="font-semibold text-lg mb-2">Ready to Create Your Visualization</h3>
              <p className="text-sm text-slate-600">
                {isValidSelection 
                  ? `Creating a ${selectedChartType} with ${selectedAggregation} aggregation`
                  : 'Please complete all required selections above'}
              </p>
            </div>
            
            <Button 
              onClick={handleContinue}
              disabled={!isValidSelection}
              className="w-full max-w-md"
              size="lg"
            >
              <ArrowRight className="h-4 w-4 mr-2" />
              Create Visualization
            </Button>
            
            {!isValidSelection && (
              <div className="text-xs text-slate-500 text-center">
                Required: X-Axis field, Y-Axis field(s), Aggregate function, and Chart type
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}