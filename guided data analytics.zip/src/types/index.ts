export interface Field {
  id: string;
  name: string;
  type: FieldType;
  visible: boolean;
}

export type FieldType = 'text' | 'numeric' | 'date';

export type Dataset = Record<string, string>[];

export interface Chart {
  id: string;
  title: string;
  type: ChartType;
  xAxis: string;
  yAxis: string;
  aggregation: AggregationType;
  data: { label: string; value: number }[];
}

export type ChartType = 'bar' | 'line' | 'pie' | 'scatter' | 'table';

export type AggregationType = 'sum' | 'mean' | 'count' | 'min' | 'max';