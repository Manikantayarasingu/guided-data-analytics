export function parseCSV(content: string): Record<string, string>[] {
  if (!content || content.trim().length === 0) {
    console.log('Empty content provided');
    return [];
  }

  const lines = content.trim().split('\n').filter(line => line.trim().length > 0);
  console.log('Total lines:', lines.length);
  
  if (lines.length < 2) {
    console.log('Not enough lines for CSV (need at least header + 1 data row)');
    return [];
  }

  // Parse headers - handle quoted headers
  const headerLine = lines[0];
  const headers = parseCSVLine(headerLine);
  console.log('Parsed headers:', headers);

  const data: Record<string, string>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const values = parseCSVLine(lines[i]);
    const row: Record<string, string> = {};
    
    headers.forEach((header, index) => {
      row[header] = values[index] || '';
    });
    
    data.push(row);
  }

  console.log('Parsed', data.length, 'rows from CSV');
  return data;
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        // Escaped quote
        current += '"';
        i++; // Skip next quote
      } else {
        // Toggle quote state
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      // End of field
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  
  // Add the last field
  result.push(current.trim());
  
  return result;
}

export function parseJSON(content: string): Record<string, string>[] {
  try {
    console.log('Parsing JSON content...');
    const parsed = JSON.parse(content);
    console.log('JSON parsed successfully, type:', typeof parsed);
    
    if (Array.isArray(parsed)) {
      console.log('JSON is array with', parsed.length, 'items');
      const result = parsed.map((item, index) => {
        const row: Record<string, string> = {};
        if (typeof item === 'object' && item !== null) {
          Object.keys(item).forEach(key => {
            row[key] = String(item[key]);
          });
        } else {
          row['value'] = String(item);
        }
        return row;
      });
      console.log('Converted', result.length, 'rows from JSON');
      return result;
    } else if (typeof parsed === 'object' && parsed !== null) {
      console.log('JSON is object, converting to single row');
      const row: Record<string, string> = {};
      Object.keys(parsed).forEach(key => {
        row[key] = String(parsed[key]);
      });
      return [row];
    }
    
    console.log('JSON format not supported');
    return [];
  } catch (error) {
    console.error('Error parsing JSON:', error);
    return [];
  }
}