export type AggregationType = 'sum' | 'mean' | 'count' | 'min' | 'max';

export function aggregate(
  data: Record<string, string>[],
  groupField: string,
  valueField: string,
  aggregationType: AggregationType
): { label: string; value: number }[] {
  const groups: Record<string, number[]> = {};

  // Group data
  data.forEach(row => {
    const group = row[groupField];
    const value = parseFloat(row[valueField]) || 0;
    
    if (!groups[group]) {
      groups[group] = [];
    }
    groups[group].push(value);
  });

  // Apply aggregation
  return Object.entries(groups).map(([label, values]) => {
    let value: number;
    
    switch (aggregationType) {
      case 'sum':
        value = values.reduce((sum, v) => sum + v, 0);
        break;
      case 'mean':
        value = values.reduce((sum, v) => sum + v, 0) / values.length;
        break;
      case 'count':
        value = values.length;
        break;
      case 'min':
        value = Math.min(...values);
        break;
      case 'max':
        value = Math.max(...values);
        break;
      default:
        value = 0;
    }

    return {
      label,
      value: Math.round(value * 100) / 100 // Round to 2 decimal places
    };
  });
}