import { FieldType } from '../hooks/useDataStore';

export function inferFieldType(values: string[]): FieldType {
  // Check if all values are empty
  if (values.every(v => v === '')) return 'text';
  
  // Remove empty values for checking
  const nonEmptyValues = values.filter(v => v !== '');
  if (nonEmptyValues.length === 0) return 'text';
  
  // Check for date pattern (YYYY-MM-DD or similar)
  const datePattern = /^\d{4}-\d{2}-\d{2}/;
  if (nonEmptyValues.every(v => datePattern.test(v))) {
    return 'date';
  }
  
  // Check if all values are numeric
  const numericValues = nonEmptyValues.filter(v => !isNaN(Number(v)) && isFinite(Number(v)));
  if (numericValues.length === nonEmptyValues.length) {
    return 'numeric';
  }
  
  // Default to text
  return 'text';
}

export function inferFieldTypes(data: Record<string, string>[]): Record<string, FieldType> {
  if (data.length === 0) return {};
  
  const fieldTypes: Record<string, FieldType> = {};
  const headers = Object.keys(data[0]);
  
  headers.forEach(header => {
    const values = data.map(row => row[header] || '');
    fieldTypes[header] = inferFieldType(values);
  });
  
  return fieldTypes;
}