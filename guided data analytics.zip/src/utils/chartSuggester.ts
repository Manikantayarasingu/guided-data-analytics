import { FieldType, ChartType } from '../types';

export function suggestChart(
  xFieldType: FieldType,
  yFieldType: FieldType,
  yFieldCount: number
): ChartType {
  // Pie chart: categorical X, single numeric Y
  if (xFieldType === 'text' && yFieldType === 'numeric' && yFieldCount === 1) {
    return 'pie';
  }

  // Line chart: date X, numeric Y
  if (xFieldType === 'date' && yFieldType === 'numeric') {
    return 'line';
  }

  // Scatter plot: numeric X, numeric Y
  if (xFieldType === 'numeric' && yFieldType === 'numeric') {
    return 'scatter';
  }

  // Default to bar chart for most cases
  return 'bar';
}

export function getAggregationForChartType(chartType: ChartType): 'sum' | 'mean' | 'count' {
  switch (chartType) {
    case 'pie':
      return 'count';
    case 'line':
      return 'mean';
    case 'scatter':
      return 'mean';
    default:
      return 'sum';
  }
}