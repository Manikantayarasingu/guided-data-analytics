import React, { createContext, useContext, useReducer, ReactNode } from 'react';

export type FieldType = 'text' | 'numeric' | 'date';
export type ChartType = 'bar' | 'line' | 'pie' | 'scatter' | 'table';
export type AggregationType = 'sum' | 'mean' | 'count' | 'min' | 'max';
export type StepType = 'upload' | 'preview' | 'configure' | 'dashboard';

export interface FieldConfig {
  name: string;
  displayName: string;
  type: FieldType;
  visible: boolean;
}

export interface ChartConfig {
  id: string;
  type: ChartType;
  xAxis: string;
  yAxis: string[];
  aggregation: AggregationType;
  title: string;
}

interface DataStore {
  data: Record<string, string>[];
  fields: FieldConfig[];
  xAxis: string | null;
  yAxis: string[];
  chartType: ChartType;
  aggregation: AggregationType;
  charts: ChartConfig[];
  currentStep: StepType;
}

type DataAction = 
  | { type: 'SET_DATA'; payload: Record<string, string>[] }
  | { type: 'SET_FIELDS'; payload: FieldConfig[] }
  | { type: 'SET_X_AXIS'; payload: string | null }
  | { type: 'SET_Y_AXIS'; payload: string[] }
  | { type: 'SET_CHART_TYPE'; payload: ChartType }
  | { type: 'SET_AGGREGATION'; payload: AggregationType }
  | { type: 'SET_CURRENT_STEP'; payload: StepType }
  | { type: 'ADD_CHART'; payload: ChartConfig }
  | { type: 'REMOVE_CHART'; payload: string }
  | { type: 'CLEAR_DATA' };

const initialState: DataStore = {
  data: [],
  fields: [],
  xAxis: null,
  yAxis: [],
  chartType: 'bar',
  aggregation: 'mean',
  charts: [],
  currentStep: 'upload'
};

function dataReducer(state: DataStore, action: DataAction): DataStore {
  switch (action.type) {
    case 'SET_DATA':
      return { ...state, data: action.payload };
    case 'SET_FIELDS':
      return { ...state, fields: action.payload };
    case 'SET_X_AXIS':
      return { ...state, xAxis: action.payload };
    case 'SET_Y_AXIS':
      return { ...state, yAxis: action.payload };
    case 'SET_CHART_TYPE':
      return { ...state, chartType: action.payload };
    case 'SET_AGGREGATION':
      return { ...state, aggregation: action.payload };
    case 'SET_CURRENT_STEP':
      return { ...state, currentStep: action.payload };
    case 'ADD_CHART':
      return { ...state, charts: [...state.charts, action.payload] };
    case 'REMOVE_CHART':
      return { ...state, charts: state.charts.filter(c => c.id !== action.payload) };
    case 'CLEAR_DATA':
      return initialState;
    default:
      return state;
  }
}

const DataContext = createContext<{
  state: DataStore;
  dispatch: React.Dispatch<DataAction>;
} | null>(null);

interface DataProviderProps {
  children: ReactNode;
}

export function DataProvider(props: DataProviderProps) {
  const [state, dispatch] = useReducer(dataReducer, initialState);
  
  const contextValue = {
    state: state,
    dispatch: dispatch
  };
  
  return React.createElement(
    DataContext.Provider,
    { value: contextValue },
    props.children
  );
}

export function useDataStore() {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useDataStore must be used within a DataProvider');
  }
  
  const { state, dispatch } = context;
  
  return {
    data: state.data,
    fields: state.fields,
    xAxis: state.xAxis,
    yAxis: state.yAxis,
    chartType: state.chartType,
    aggregation: state.aggregation,
    charts: state.charts,
    currentStep: state.currentStep,
    setData: (data: Record<string, string>[]) => dispatch({ type: 'SET_DATA', payload: data }),
    setFields: (fields: FieldConfig[]) => dispatch({ type: 'SET_FIELDS', payload: fields }),
    setXAxis: (xAxis: string | null) => dispatch({ type: 'SET_X_AXIS', payload: xAxis }),
    setYAxis: (yAxis: string[]) => dispatch({ type: 'SET_Y_AXIS', payload: yAxis }),
    setChartType: (chartType: ChartType) => dispatch({ type: 'SET_CHART_TYPE', payload: chartType }),
    setAggregation: (aggregation: AggregationType) => dispatch({ type: 'SET_AGGREGATION', payload: aggregation }),
    setCurrentStep: (currentStep: StepType) => dispatch({ type: 'SET_CURRENT_STEP', payload: currentStep }),
    addChart: (chart: ChartConfig) => dispatch({ type: 'ADD_CHART', payload: chart }),
    removeChart: (chartId: string) => dispatch({ type: 'REMOVE_CHART', payload: chartId }),
    clearData: () => dispatch({ type: 'CLEAR_DATA' })
  };
}