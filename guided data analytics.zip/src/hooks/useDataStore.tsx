import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Field, Chart, Dataset, FieldType, ChartType, AggregationType } from '../types';

interface DataStoreContextType {
  data: Dataset;
  fields: Field[];
  charts: Chart[];
  hasData: boolean;
  
  // Actions
  setData: (data: Dataset) => void;
  updateField: (index: number, field: Partial<Field>) => void;
  addChart: (chart: Chart) => void;
  removeChart: (id: string) => void;
  clearData: () => void;
}

const DataStoreContext = createContext<DataStoreContextType | undefined>(undefined);

interface DataStoreProviderProps {
  children: ReactNode;
}

export function DataStoreProvider({ children }: DataStoreProviderProps) {
  const [data, setDataState] = useState<Dataset>([]);
  const [fields, setFields] = useState<Field[]>([]);
  const [charts, setCharts] = useState<Chart[]>([]);

  const hasData = data.length > 0;

  const setData = (newData: Dataset) => {
    if (newData.length === 0) {
      setDataState([]);
      setFields([]);
      setCharts([]);
      return;
    }

    const sampleRow = newData[0];
    const newFields: Field[] = Object.keys(sampleRow).map((key, index) => ({
      id: `field-${index}`,
      name: key,
      displayName: key,
      type: inferType(newData.map(row => row[key])),
      visible: true,
    }));

    setDataState(newData);
    setFields(newFields);
  };

  const updateField = (index: number, updatedField: Partial<Field>) => {
    setFields(prevFields => 
      prevFields.map((field, i) =>
        i === index ? { ...field, ...updatedField } : field
      )
    );
  };

  const addChart = (chart: Chart) => {
    setCharts(prevCharts => [...prevCharts, chart]);
  };

  const removeChart = (id: string) => {
    setCharts(prevCharts => prevCharts.filter(chart => chart.id !== id));
  };

  const clearData = () => {
    setDataState([]);
    setFields([]);
    setCharts([]);
  };

  const value: DataStoreContextType = {
    data,
    fields,
    charts,
    hasData,
    setData,
    updateField,
    addChart,
    removeChart,
    clearData,
  };

  return React.createElement(
    DataStoreContext.Provider,
    { value },
    children
  );
}

export function useDataStore(): DataStoreContextType {
  const context = useContext(DataStoreContext);
  if (!context) {
    throw new Error('useDataStore must be used within a DataStoreProvider');
  }
  return context;
}

// Helper function to infer field type
function inferType(values: string[]): FieldType {
  const nonEmptyValues = values.filter(v => v !== '');
  
  if (nonEmptyValues.length === 0) return 'text';
  
  // Check for date
  const datePattern = /^\d{4}-\d{2}-\d{2}/;
  if (nonEmptyValues.every(v => datePattern.test(v))) {
    return 'date';
  }
  
  // Check for numeric
  const numericValues = nonEmptyValues.filter(v => !isNaN(Number(v)) && v !== '');
  if (numericValues.length / nonEmptyValues.length > 0.8) {
    return 'numeric';
  }
  
  return 'text';
}