import { DataProvider } from './hooks/useDataStore';
import DataUpload from './components/DataUpload';
import { DataPreview } from './components/DataPreview';
import { AxisConfig } from './components/AxisConfig';
import { Dashboard } from './components/Dashboard';

function App() {
  return (
    <DataProvider>
      <div className="min-h-screen bg-slate-50">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-900">Guided Data Explorer</h1>
            <p className="text-slate-600 mt-2">Transform your CSV/JSON data into beautiful charts with zero backend</p>
          </div>
          
          <div className="max-w-6xl mx-auto">
            <DataUpload />
            <DataPreview />
            <AxisConfig />
            <Dashboard />
          </div>
        </div>
      </div>
    </DataProvider>
  );
}

export default App;